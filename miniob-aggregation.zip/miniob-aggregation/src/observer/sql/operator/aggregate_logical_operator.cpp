#include "sql/operator/aggregate_logical_operator.h"

AggregateLogicalOperator::AggregateLogicalOperator(const std::vector<Field> &field):fields_(field){};